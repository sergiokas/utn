
# Install

`$ sudo apt-get install libncurses-dev`

# Demo
Ingresar "0,1,X" para dibujar el caracter "X" en el casillero 0,1